import React, { Component } from 'react';
import { View, WebView, StatusBar } from 'react-native';

export default class App extends Component {
    render() {

        var webViewCode = `
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script type="text/javascript" src="https://static.codehs.com/gulp/89cd3118fd3b4fab9f913ce7091f1761944163e8/chs-js-lib/chs.js"></script>

<style>
    body, html {
        margin: 0;
        padding: 0;
    }
    canvas {
        margin: 0px;
        padding: 0px;
        display: inline-block;
        vertical-align: top;
    }
    #btn-container {
        text-align: center;
        padding-top: 10px;
    }
    #btn-play {
        background-color: #8cc63e;
    }
    #btn-stop {
        background-color: #de5844;
    }
    .glyphicon {
        margin-top: -3px;
        color: #FFFFFF;
    }
</style>
</head>

<body>
    <div id="canvas-container" style="margin: 0 auto; ">
        <canvas
        id="game"
        width="400"
        height="480"
        class="codehs-editor-canvas"
        style="width: 100%; height: 100%; margin: 0 auto;"
        ></canvas>
    </div>
    <div id="console"></div>
    <div id="btn-container">
        <button class="btn btn-main btn-lg" id="btn-play" onclick='stopProgram(); runProgram();'><span class="glyphicon glyphicon-play" aria-hidden="true"></span></button>
        <button class="btn btn-main btn-lg" id="btn-stop" onclick='stopProgram();'><span class="glyphicon glyphicon-stop" aria-hidden="true"></span></button>
    </div>

<script>
    var console = {};
    console.log = function(msg){
        $("#console").html($("#console").html() + "     " + msg);
    };

    var runProgram = function() {
        function start() {
    
    println("Welcome to BINGO!! Here come the balls: ");
    
    // Creating the BINGO board //
    
    //
    
    var maxX = getWidth();
    var maxY = getHeight();

    
    var topborder = new Line(30,50,maxX-30,50);
    add(topborder);
    var bottomborder = new Line(30,maxY-50,maxX-30,maxY-50);
    add(bottomborder);
    var leftborder = new Line(30,50,30,maxY-50);
    add(leftborder);
    var rightborder = new Line(maxX-30,50,maxX-30,maxY-50);
    add(rightborder);
    var rowB = new Line(98,50,98,maxY-50);
    add(rowB);
    var rowI = new Line(166,50,166,maxY-50);
    add(rowI);
    var rowN = new Line(234,50,234,maxY-50);
    add(rowN);
    var rowG = new Line(302,50,302,maxY-50);
    add(rowG);
    var row1 = new Line(30,113,maxX-30,113);
    add(row1);
    var row2 = new Line(30,176,maxX-30,176);
    add(row2);
    var row3 = new Line(30,239,maxX-30,239);
    add(row3);
    var row4 = new Line(30,303,maxX-30,303);
    add(row4);
    var row5 = new Line(30,366,maxX-30,366);
    add(row5);
    
    var bText = new Text('B', '60pt Arial');
    bText.setPosition(40,110);
    add(bText);
    var iText = new Text('I', '60pt Arial');
    iText.setPosition(120,110);
    add(iText);
    var nText = new Text('N', '60pt Arial');
    nText.setPosition(170,110);
    add(nText);
    var gText = new Text('G', '60pt Arial');
    gText.setPosition(235,110);
    add(gText);
    var oText = new Text('O', '60pt Arial');
    oText.setPosition(305,110);
    add(oText);
    
    //
    //Ball Randomizer-
    setTimer(bingoball,3000);
    function bingoball() {
    var callBall = Randomizer.nextInt(1,75);
    
    if(callBall <= 15) {
        println("The ball is B " + callBall);
    }
    if(callBall <= 30 && callBall > 15) {
        println("The ball is I " + callBall);
    }
    if(callBall <= 45 && callBall > 30) {
        println("The ball is N " + callBall);
    }
    if(callBall <= 60 && callBall > 45) {
        println("The ball is G " + callBall);
    }
    if(callBall <= 75 && callBall > 60) {
        println("The ball is O " + callBall);
    }
    }
    mouseClickMethod(addBall);
    
    //Numbers on the board
    var numB1 = Randomizer.nextInt(1,3);
    var numB1text = new Text(numB1,'45pt Arial');
    numB1text.setPosition(32,170);
    numB1text.setColor(Color.red);
    add(numB1text);
    var numB2 = Randomizer.nextInt(4,6);
    var numB2text = new Text(numB2,'45pt Arial');
    numB2text.setPosition(32,225);
    numB2text.setColor(Color.red);
    add(numB2text);
    var numB3 = Randomizer.nextInt(7,9);
    var numB3text = new Text(numB3,'45pt Arial');
    numB3text.setPosition(32,290);
    numB3text.setColor(Color.red);
    add(numB3text);
    var numB4 = Randomizer.nextInt(10,12);
    var numB4text = new Text(numB4,'45pt Arial');
    numB4text.setPosition(32,350);
    numB4text.setColor(Color.red);
    add(numB4text);
    var numB5 = Randomizer.nextInt(13,15);
    var numB5text = new Text(numB5,'45pt Arial');
    numB5text.setPosition(32,425);
    numB5text.setColor(Color.red);
    add(numB5text);
    var numI1 = Randomizer.nextInt(16,18);
    var numI1text = new Text(numI1,'45pt Arial');
    numI1text.setPosition(100,170);
    numI1text.setColor(Color.orange);
    add(numI1text);
    var numI2 = Randomizer.nextInt(19,21);
    var numI2text = new Text(numI2,'45pt Arial');
    numI2text.setPosition(100,225);
    numI2text.setColor(Color.orange);
    add(numI2text);
    var numI3 = Randomizer.nextInt(22,24);
    var numI3text = new Text(numI3,'45pt Arial');
    numI3text.setPosition(100,290);
    numI3text.setColor(Color.orange);
    add(numI3text);
    var numI4 = Randomizer.nextInt(25,27);
    var numI4text = new Text(numI4,'45pt Arial');
    numI4text.setPosition(100,350);
    numI4text.setColor(Color.orange);
    add(numI4text);
    var numI5 = Randomizer.nextInt(28,30);
    var numI5text = new Text(numI5,'45pt Arial');
    numI5text.setPosition(100,425);
    numI5text.setColor(Color.orange);
    add(numI5text);
    var numN1 = Randomizer.nextInt(31,33);
    var numN1text = new Text(numN1,'45pt Arial');
    numN1text.setPosition(168,170);
    numN1text.setColor(Color.green);
    add(numN1text);
    var numN2 = Randomizer.nextInt(34,36);
    var numN2text = new Text(numN2,'45pt Arial');
    numN2text.setPosition(168,225);
    numN2text.setColor(Color.green);
    add(numN2text);
    var numN3 = Randomizer.nextInt(37,39);
    var numN3text = new Text(numN3,'45pt Arial');
    numN3text.setPosition(168,290);
    numN3text.setColor(Color.green);
    add(numN3text);
    var numN4 = Randomizer.nextInt(40,42);
    var numN4text = new Text(numN4,'45pt Arial');
    numN4text.setPosition(168,350);
    numN4text.setColor(Color.green);
    add(numN4text);
    var numN5 = Randomizer.nextInt(43,45);
    var numN5text = new Text(numN5,'45pt Arial');
    numN5text.setPosition(168,425);
    numN5text.setColor(Color.green);
    add(numN5text);
    var numG1 = Randomizer.nextInt(46,48);
    var numG1text = new Text(numG1,'45pt Arial');
    numG1text.setPosition(236,170);
    numG1text.setColor(Color.blue);
    add(numG1text);
    var numG2 = Randomizer.nextInt(49,51);
    var numG2text = new Text(numG2,'45pt Arial');
    numG2text.setPosition(236,225);
    numG2text.setColor(Color.blue);
    add(numG2text);
    var numG3 = Randomizer.nextInt(52,54);
    var numG3text = new Text(numG3,'45pt Arial');
    numG3text.setPosition(236,290);
    numG3text.setColor(Color.blue);
    add(numG3text);
    var numG4 = Randomizer.nextInt(55,57);
    var numG4text = new Text(numG4,'45pt Arial');
    numG4text.setPosition(236,350);
    numG4text.setColor(Color.blue);
    add(numG4text);
    var numG5 = Randomizer.nextInt(58,60);
    var numG5text = new Text(numG5,'45pt Arial');
    numG5text.setPosition(236,425);
    numG5text.setColor(Color.blue);
    add(numG5text);
    var numO1 = Randomizer.nextInt(61,63);
    var numO1text = new Text(numO1,'45pt Arial');
    numO1text.setPosition(304,170);
    numO1text.setColor(Color.purple);
    add(numO1text);
    var numO2 = Randomizer.nextInt(64,66);
    var numO2text = new Text(numO2,'45pt Arial');
    numO2text.setPosition(304,225);
    numO2text.setColor(Color.purple);
    add(numO2text);
    var numO3 = Randomizer.nextInt(67,69);
    var numO3text = new Text(numO3,'45pt Arial');
    numO3text.setPosition(304,290);
    numO3text.setColor(Color.purple);
    add(numO3text);
    var numO4 = Randomizer.nextInt(70,72);
    var numO4text = new Text(numO4,'45pt Arial');
    numO4text.setPosition(304,350);
    numO4text.setColor(Color.purple);
    add(numO4text);
    var numO5 = Randomizer.nextInt(73,75);
    var numO5text = new Text(numO5,'45pt Arial');
    numO5text.setPosition(304,425);
    numO5text.setColor(Color.purple);
    add(numO5text);
    /*
    var numB1 = Randomizer.nextInt(1,15);
    var numB1text = new Text(numB1,'45pt Arial');
    numB1text.setPosition(32,170);
    add(numB1text);
    var numB2 = Randomizer.nextInt(1,15);
    var numB2text = new Text(numB2,'45pt Arial');
    numB2text.setPosition(32,225);
    add(numB2text);
    */
    //
    
    
    ///
    
    
    
    
    
    /*if(numB1 == numB2) {
        println(numB1);
        remove(numB1text);
        var newnumB1 = Randomizer.nextInt(1,15);
        var newnumB1text = new Text(newnumB1,'45pt Arial');
        newnumB1text.setPosition(32,170);
        add(newnumB1text);
        println(newnumB1);
    } */
    /*if(numB1 == numB3) {
        remove(numB1text);
        var newnumB1 = Randomizer.nextInt(1,15);
        var newnumB1text = new Text(newnumB1,'45pt Arial');
        newnumB1text.setPosition(32,170);
        add(newnumB1text);
        println(newnumB1);
    }
    if(numB1 == numB4) {
        remove(numB1text);
        var newnumB1 = Randomizer.nextInt(1,15);
        var newnumB1text = new Text(newnumB1,'45pt Arial');
        newnumB1text.setPosition(32,170);
        add(newnumB1text);
        println(newnumB1);
    }
    if(numB1 == numB5) {
        remove(numB1text);
        var newnumB1 = Randomizer.nextInt(1,15);
        var newnumB1text = new Text(newnumB1,'45pt Arial');
        newnumB1text.setPosition(32,170);
        add(newnumB1text);
        println(newnumB1);
    }
    */
    //
    
    
    
    //
    
    
    /*var numB3 = Randomizer.nextInt(1,15);
    var numB3text = new Text(numB3,'45pt Arial');
    numB3text.setPosition(32,290);
    add(numB3text);
    var numB4 = Randomizer.nextInt(1,15);
    var numB4text = new Text(numB4,'45pt Arial');
    numB4text.setPosition(32,350);
    add(numB4text);
    var numB5 = Randomizer.nextInt(1,15);
    var numB5text = new Text(numB5,'45pt Arial');
    numB5text.setPosition(32,425);
    add(numB5text);
    var numI1 = Randomizer.nextInt(16,30);
    var numI1text = new Text(numI1,'45pt Arial');
    numI1text.setPosition(100,170);
    add(numI1text);
    var numI2 = Randomizer.nextInt(16,30);
    var numI2text = new Text(numI2,'45pt Arial');
    numI2text.setPosition(100,225);
    add(numI2text);
    var numI3 = Randomizer.nextInt(16,30);
    var numI3text = new Text(numI3,'45pt Arial');
    numI3text.setPosition(100,290);
    add(numI3text);
    var numI4 = Randomizer.nextInt(16,30);
    var numI4text = new Text(numI4,'45pt Arial');
    numI4text.setPosition(100,350);
    add(numI4text);
    var numI5 = Randomizer.nextInt(16,30);
    var numI5text = new Text(numI5,'45pt Arial');
    numI5text.setPosition(100,425);
    add(numI5text);
    var numN1 = Randomizer.nextInt(31,45);
    var numN1text = new Text(numN1,'45pt Arial');
    numN1text.setPosition(168,170);
    add(numN1text);
    var numN2 = Randomizer.nextInt(31,45);
    var numN2text = new Text(numN2,'45pt Arial');
    numN2text.setPosition(168,225);
    add(numN2text);
    var numN3 = Randomizer.nextInt(31,45);
    var numN3text = new Text(numN3,'45pt Arial');
    numN3text.setPosition(168,290);
    add(numN3text);
    var numN4 = Randomizer.nextInt(31,45);
    var numN4text = new Text(numN4,'45pt Arial');
    numN4text.setPosition(168,350);
    add(numN4text);
    var numN5 = Randomizer.nextInt(31,45);
    var numN5text = new Text(numN5,'45pt Arial');
    numN5text.setPosition(168,425);
    add(numN5text);
    var numG1 = Randomizer.nextInt(46,60);
    var numG1text = new Text(numG1,'45pt Arial');
    numG1text.setPosition(236,170);
    add(numG1text);
    var numG2 = Randomizer.nextInt(46,60);
    var numG2text = new Text(numG2,'45pt Arial');
    numG2text.setPosition(236,225);
    add(numG2text);
    var numG3 = Randomizer.nextInt(46,60);
    var numG3text = new Text(numG3,'45pt Arial');
    numG3text.setPosition(236,290);
    add(numG3text);
    var numG4 = Randomizer.nextInt(46,60);
    var numG4text = new Text(numG4,'45pt Arial');
    numG4text.setPosition(236,350);
    add(numG4text);
    var numG5 = Randomizer.nextInt(46,60);
    var numG5text = new Text(numG5,'45pt Arial');
    numG5text.setPosition(236,425);
    add(numG5text);
    var numO1 = Randomizer.nextInt(61,75);
    var numO1text = new Text(numO1,'45pt Arial');
    numO1text.setPosition(304,170);
    add(numO1text);
    var numO2 = Randomizer.nextInt(61,75);
    var numO2text = new Text(numO2,'45pt Arial');
    numO2text.setPosition(304,225);
    add(numO2text);
    var numO3 = Randomizer.nextInt(61,75);
    var numO3text = new Text(numO3,'45pt Arial');
    numO3text.setPosition(304,290);
    add(numO3text);
    var numO4 = Randomizer.nextInt(61,75);
    var numO4text = new Text(numO4,'45pt Arial');
    numO4text.setPosition(304,350);
    add(numO4text);
    var numO5 = Randomizer.nextInt(61,75);
    var numO5text = new Text(numO5,'45pt Arial');
    numO5text.setPosition(304,425);
    add(numO5text);
*/
function addBall(e) {
	var ball = new Circle(30);
	var hitmarker = new Audio('http://www.flashkit.com/imagesvr_ce/flashkit/soundfx/Interfaces/Pops/Hit_Mark-Metallic-9040/Hit_Mark-Metallic-9040_hifi.mp3');
	ball.setPosition(e.getX(), e.getY());
    ball.setPosition(e.getX(),e.getY());
	add(ball);
	hitmarker.play();
    
}
}


        if (typeof start === 'function') {
            start();
        }

        // Overrides setSize() if called from the user's code. Needed because
        // we have to change the canvas size and attributes to reflect the
        // user's desired program size. Calling setSize() from user code only
        // has an effect if Fit to Full Screen is Off. If Fit to Full Screen is
        // On, then setSize() does nothing.
        function setSize(width, height) {
            if (!true) {
                // Call original graphics setSize()
                window.__graphics__.setSize(width, height);

                // Scale to screen width but keep aspect ratio of program
                // Subtract 2 to allow for border
                var canvasWidth = window.innerWidth - 2;
                var canvasHeight = canvasWidth * getHeight() / getWidth();

                // Make canvas reflect desired size set
                adjustMarginTop(canvasHeight);
                setCanvasContainerSize(canvasWidth, canvasHeight);
                setCanvasAttributes(canvasWidth, canvasHeight);
            }
        }
    };

    var stopProgram = function() {
        removeAll();
        window.__graphics__.fullReset();
    }

    window.onload = function() {
        if (!false) {
            $('#btn-container').remove();
        }

        var canvasWidth;
        var canvasHeight;
        if (true) {
            // Get device window width and set program size to those dimensions
            setSize(window.innerWidth, window.innerHeight);
            canvasWidth = getWidth();
            canvasHeight = getHeight();

            if (false) {
                // Make room for buttons if being shown
                $('#btn-container').css('padding', '5px 0');
                canvasHeight -= $('#btn-container').outerHeight();
            }

            setCanvasAttributes(canvasWidth, canvasHeight);
        } else {
            // Scale to screen width but keep aspect ratio of program
            // Subtract 2 to allow for border
            canvasWidth = window.innerWidth - 2;
            canvasHeight = canvasWidth * getHeight() / getWidth();

            // Light border around canvas if not full screen
            $('#canvas-container').css('border', '1px solid #beccd4');

            adjustMarginTop(canvasHeight);
        }

        setCanvasContainerSize(canvasWidth, canvasHeight);

        if (true) {
            runProgram();
        }
    };

    // Set the canvas container width and height.
    function setCanvasContainerSize(width, height) {
        $('#canvas-container').width(width);
        $('#canvas-container').height(height);
    }

    // Set the width and height attributes of the canvas. Allows
    // getTouchCoordinates to sense x and y correctly.
    function setCanvasAttributes(canvasWidth, canvasHeight) {
        $('#game').attr('width', canvasWidth);
        $('#game').attr('height', canvasHeight);
    }

    // Assumes the Fit to Full Screen setting is Off. Adjusts the top margin
    // depending on the Show Play/Stop Buttons setting.
    function adjustMarginTop(canvasHeight) {
        var marginTop = (window.innerHeight - canvasHeight)/2;
        if (false) {
            marginTop -= $('#btn-container').height()/3;
        }
        $('#canvas-container').css('margin-top', marginTop);
    }
</script>
</body>
</html>
`;
        return (
            <View style={{ flex: 1 }}>
                <StatusBar hidden />
                <WebView
                    source={{html: webViewCode, baseUrl: "/"}}
                    javaScriptEnabled={true}
                    style={{ flex: 1 }}
                    scrollEnabled={false}
                    bounces={false}
                    scalesPageToFit={false}
                ></WebView>
            </View>
        );
    }
}
